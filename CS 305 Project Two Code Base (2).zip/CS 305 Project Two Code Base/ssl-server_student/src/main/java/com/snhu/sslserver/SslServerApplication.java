package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class SeverController{
	@RequestMapping("/hash")
	public String myHash() throws NoSuchAlgorithmException{
		String data = "Andrew Bolton";
		String outputLine;
		
		MessageDigest mDigest = MessageDigest.getInstance("SHA-256"); 
		mDigest.update(data.getBytes());
		byte[] digest = mDigest.digest();
		StringBuffer hexString = new StringBuffer();
		for (int i =0;i< digest.length; i++) {
			hexString.append(Integer.toHexString(0xFF & digest[i]));
		}
	    outputLine = "Data output: " +data+ "CheckSum Value: " +hexString.toString();
	    return outputLine; 
	}
}
